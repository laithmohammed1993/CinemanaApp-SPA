# Cinemana App
#### It is Single Page Application

#### Features :
 - search option
 - arrow keys navigation
 - store items
 - responsive application

[Cinemana App Demo](https://cinemana-spa.herokuapp.com/)
![Image description](https://cinemana-spa.herokuapp.com/assets/images/cover.jpg)

#### How to install :
  - typing into terminal :

```bash
node server.js
```
    
    
    